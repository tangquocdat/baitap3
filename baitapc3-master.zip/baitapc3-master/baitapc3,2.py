def chuyen(a):
    for i in a:
        print(i.capitalize())
a=str(input("nhap chuoi: "))
chuyen(a)
